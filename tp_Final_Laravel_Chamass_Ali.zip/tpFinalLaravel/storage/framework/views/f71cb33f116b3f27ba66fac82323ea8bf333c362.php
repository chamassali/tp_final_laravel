

<?php $__env->startSection('title'); ?>
<h1>Modifier un élève</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>

<main style="width: 50%; margin: 20px auto;">

    <form action="<?php echo e(route('eleve.update', $eleve)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <div class="grix xs1 sm2">
            <div class="form-field">
                <label for="firstname">First name</label>
                <input type="text" id="firstname" name="firstname" class="form-control rounded-1" value="<?php echo e($eleve['firstname']); ?>" />
            </div>
            <div class="form-field">
                <label class="txt-right hide-xs" for="lastname">Last name</label>
                <label class="txt-left hide-sm-up" for="lastname">lastname</label>
                <input type="text" id="lastname" name="lastname" class="form-control rounded-1" value="<?php echo e($eleve['lastname']); ?>" />
            </div>
            <div class="form-field">
                <label class="txt-left hide-xs" for="email">Email</label>
                <label class="txt-left hide-sm-up" for="email">Email</label>
                <input type="email" id="email" name="email" class="form-control rounded-1" value="<?php echo e($eleve['email']); ?>" />
            </div>
            <div class="form-field">
                <label class="txt-right hide-xs" for="search">Promo</label>
                <select class="form-control rounded-1" id="select" name="promo">
                    <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($promo->id); ?>" <?php if($promo->id == $eleve->promos['id']): ?>
                        selected
                        <?php endif; ?>
                        ><?php echo e($promo->name); ?> <?php echo e($promo->specialty); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <input class="btn shadow-1 rounded-1 small grey dark-5 uppercase" type="submit" value="EDIT">
        </div>
    </form>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/eleve/edit.blade.php ENDPATH**/ ?>