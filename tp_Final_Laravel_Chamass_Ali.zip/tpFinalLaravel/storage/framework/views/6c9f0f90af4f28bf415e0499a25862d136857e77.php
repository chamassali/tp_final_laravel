

<?php $__env->startSection('title'); ?>
<h1>Details</h1> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>


<main style="width: 50%; margin: 20px auto;">

    <div class="card shadow-1">
        <div class="card-header">
            <h2>Module : <?php echo e($module['name']); ?></h2>
            <h4>Description : <?php echo e($module['description']); ?></h4>
        </div>
        <div class="card-content">
            <h5>Liste des promos</h5>

            <?php $__currentLoopData = $module->promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($promo->name); ?> <?php echo e($promo->specialty); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <h5>Liste des élèves</h5>

            <?php $__currentLoopData = $module->eleves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($eleve->firstname); ?> <?php echo e($eleve->lastname); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="card-footer">
            <a class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('promo.index', ['module_id'=>$module->id])); ?>">
                Ajouter des promos
            </a>
            <a class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('eleve.index', ['module_id'=>$module->id])); ?>">
                Ajouter des élèves
            </a>
        </div>
    </div>

    <td></td>
    <td></td>
    <td></td>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/module/show.blade.php ENDPATH**/ ?>