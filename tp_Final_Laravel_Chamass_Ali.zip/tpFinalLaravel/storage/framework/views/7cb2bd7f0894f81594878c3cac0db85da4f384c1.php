<main style="width: 50%; margin: 20px auto;">
    <form method="POST" action="<?php echo e(route('module.storePromo', ['module_id' => $current_module_id])); ?>">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h6>
            <input type="checkbox" class="form-check" id="module-<?php echo e($promo->id); ?>" value="<?php echo e($promo->id); ?>" name="promos[]" <?php $__currentLoopData = $promo->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliverable_module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($deliverable_module->id == $current_module_id): ?> checked <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
            <label for="promo-<?php echo e($promo->id); ?>"><?php echo e($promo->name); ?> <?php echo e($promo->specialty); ?></label>
        </h6>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="submit" class="btn shadow-1 rounded-1 small grey dark-5 uppercase"><span class="outline-text">Ajouter</span></button>
    </form>
</main><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/promo/parts/promo_form_create.blade.php ENDPATH**/ ?>