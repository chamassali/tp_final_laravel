

<?php $__env->startSection('title'); ?>
<div style="width: 30%; margin-left: 20px;">
    <h1>Liste des promos</h1>

    <form>
        <div class="grix xs1 sm2">
            <div class="form-field">
                <input type="text" id="search" name="search" class="form-control rounded-1" placeholder="Search...." />
                <button style="margin-top: 10px;" type="submit" class="btn shadow-1 rounded-1 small grey dark-5 uppercase">
                    Chercher
                </button>
            </div>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>

<?php if(isset($current_module_id)): ?>
    <?php echo $__env->make("promo.parts.promo_form_create", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make("promo.parts.list", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/promo/index.blade.php ENDPATH**/ ?>