

<?php $__env->startSection('title'); ?>
<h1>Ajouter un module</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>

<main style="width: 50%; margin: 20px auto;">
    <form method="POST" action="<?php echo e(route('module.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="grix xs1 sm2">
            <div class="form-field">
                <label for="firstname">Nom du module</label>
                <input type="text" id="module" name="module" class="form-control rounded-1" placeholder="Nom du module" />
            </div>
            <div class="form-field">
                <label class="txt-right hide-xs" for="description">Description</label>
                <label class="txt-left hide-sm-up" for="description">Description</label>
                <input type="text" id="description" name="description" class="form-control rounded-1" placeholder="Decription du module" />
            </div>
            <input class="btn shadow-1 rounded-1 small grey dark-5 uppercase" type="submit" value="ADD">
        </div>
    </form>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/module/create.blade.php ENDPATH**/ ?>