<main style="width: 50%; margin: 20px auto;">
    <form method="POST" action="<?php echo e(route('module.storeEleve', ['module_id' => $current_module_id])); ?>">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $eleves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h6>
            <input type="checkbox" class="form-check" id="module-<?php echo e($eleve->id); ?>" value="<?php echo e($eleve->id); ?>" name="eleves[]" <?php $__currentLoopData = $eleve->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliverable_module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($deliverable_module->id == $current_module_id): ?> checked <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
            <label for="eleve-<?php echo e($eleve->id); ?>"><?php echo e($eleve->firstname); ?> <?php echo e($eleve->lastname); ?></label>
        </h6>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="submit" class="btn shadow-1 rounded-1 small grey dark-5 uppercase"><span class="outline-text">Ajouter</span></button>
    </form>
</main><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/eleve/parts/eleve_form_create.blade.php ENDPATH**/ ?>