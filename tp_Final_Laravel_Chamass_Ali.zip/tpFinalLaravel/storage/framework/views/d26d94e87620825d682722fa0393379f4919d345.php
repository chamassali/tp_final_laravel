<main style="width: 50%; margin: 20px auto;">
    <form method="POST" action="<?php echo e(route('promo.storeModule', ['promo_id' => $current_promo_id])); ?>">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <input type="checkbox" class="form-check" id="module-<?php echo e($module->id); ?>" value="<?php echo e($module->id); ?>" name="modules[]" <?php $__currentLoopData = $module->promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliverable_promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($deliverable_promo->id == $current_promo_id): ?> checked <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
            <label for="module-<?php echo e($module->id); ?>"><?php echo e($module->name); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button type="submit" class="btn shadow-1 rounded-1 small grey dark-5 uppercase"><span class="outline-text">Ajouter</span></button>
    </form>
</main><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/module/parts/form_create.blade.php ENDPATH**/ ?>