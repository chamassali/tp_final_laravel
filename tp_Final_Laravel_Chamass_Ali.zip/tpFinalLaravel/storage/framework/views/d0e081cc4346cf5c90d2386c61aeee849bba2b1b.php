

<?php $__env->startSection('title'); ?>
Liste des promos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>
<a style="margin-left: 20px;" class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('promo.create')); ?>">Add a promo</a>
<main style="width: 50%; margin: 20px auto;">

    <div class="responsive-table-2">
        <table class="table">

            <thead>
                <tr>
                    <th>Name</th>
                    <th>Specialty</th>
                    <th></th>
                </tr>
            </thead>


            <?php $__currentLoopData = $promos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo e($promo['name']); ?></td>
                    <td><?php echo e($promo['specialty']); ?></td>
                    <td>
                        <div style="display: flex;">
                            <a class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('promo.show', $promo)); ?>">Details</a>
                            <a style="margin-left: 20px;" class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('promo.edit', $promo)); ?>">Edit</a>
                            <form style="margin-left: 20px;" action="<?php echo e(route('promo.destroy', $promo)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <input class="btn shadow-1 rounded-1 small grey dark-5 uppercase" type="submit" value="Delete">
                            </form>
                        </div>


                    </td>

                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/promo/parts/list.blade.php ENDPATH**/ ?>