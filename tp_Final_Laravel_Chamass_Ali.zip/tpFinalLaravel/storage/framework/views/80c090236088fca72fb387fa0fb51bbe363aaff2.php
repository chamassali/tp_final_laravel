

<?php $__env->startSection('title'); ?>
Liste des élèves
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>
<a style="margin-left: 20px;" class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('eleve.create')); ?>">Ajouter un élève</a>

<main style="width: 50%; margin: 20px auto;">

    <div class="responsive-table-2">
        <table class="table">

            <thead>
                <tr>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th></th>
                </tr>
            </thead>

            <?php $__currentLoopData = $eleves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo e($eleve['firstname']); ?></td>
                    <td><?php echo e($eleve['lastname']); ?></td>
                    <td><?php echo e($eleve['email']); ?></td>
                    <td>
                        <div style="display: flex;">
                            <a class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('eleve.show', $eleve)); ?>">Details</a>
                            <a style="margin-left: 20px;" class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('eleve.edit', $eleve)); ?>">Edit</a>
                            <form style="margin-left: 20px;" action="<?php echo e(route('eleve.destroy', $eleve)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <input class="btn shadow-1 rounded-1 small grey dark-5 uppercase" type="submit" value="Delete">
                            </form>
                        </div>

                    </td>
                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/eleve/parts/list.blade.php ENDPATH**/ ?>