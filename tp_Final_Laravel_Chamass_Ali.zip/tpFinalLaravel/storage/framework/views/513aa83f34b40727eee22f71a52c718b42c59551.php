

<?php $__env->startSection('contenu'); ?>
<a style="margin-left: 20px;" class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('module.create')); ?>">Ajouter un module</a>

<main style="width: 50%; margin: 20px auto;">
    <div class="responsive-table-2">
        <table class="table">

            <thead>
                <tr>
                    <th>Name</th>
                    <th>Description </th>
                    <th></th>
                </tr>
            </thead>

            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo e($module['name']); ?></td>
                    <td><?php echo e($module['description']); ?></td>
                    <td>
                        <div style="display: flex;">
                            <a class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('module.show', $module)); ?>">Details</a>
                            <a style="margin-left: 20px;" class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('module.edit', $module)); ?>">Edit</a>
                            <form style="margin-left: 20px;" action="<?php echo e(route('module.destroy', $module)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("DELETE"); ?>
                                <input class="btn shadow-1 rounded-1 small grey dark-5 uppercase" type="submit" value="Delete">
                            </form>

                        </div>

                    </td>

                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/module/parts/list.blade.php ENDPATH**/ ?>