

<?php $__env->startSection('title'); ?>
Toulouse Ynov Campus
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>
<main style="width: 65%; margin: 20px auto;">
    <div class="responsive-table-2">
        <table class="table">

            <thead>
                <tr>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Email</th>
                    <th>Promotion</th>
                    <th></th>

                </tr>
            </thead>


            <?php $__currentLoopData = $eleves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eleve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tbody>
                <tr>
                    <td><?php echo e($eleve['firstname']); ?></td>
                    <td><?php echo e($eleve['lastname']); ?></td>
                    <td><?php echo e($eleve['email']); ?></td>
                    <td></td>
                    <td>
                        <button class="btn shadow-1 rounded-1 small grey dark-5 uppercase">Details</button>
                        <button class="btn shadow-1 rounded-1 small grey dark-5 uppercase">Edit</button>
                        <button class="btn shadow-1 rounded-1 small grey dark-5 uppercase">Delete</button>
                    </td>

                </tr>
            </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/index.blade.php ENDPATH**/ ?>