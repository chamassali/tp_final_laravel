

<?php $__env->startSection('title'); ?>
<h1>Details</h1> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenu'); ?>


<main style="width: 50%; margin: 20px auto;">

    <div class="card shadow-1">
        <div class="card-header">
            <h2><?php echo e($eleve['firstname']); ?> <?php echo e($eleve['lastname']); ?></h2>
        </div>
        <div class="card-content">

            <h5> Email :</h5>
            <h6><?php echo e($eleve['email']); ?></h6>
            <h5>Promo :</h5>
            <h6><?php echo e($eleve->promos['name']); ?> <?php echo e($eleve->promos['specialty']); ?></h6>

            <h5>Modules :</h5>
            <?php $__currentLoopData = $eleve->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($module->name); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="card-footer">
            <a class="btn shadow-1 rounded-1 small grey dark-5 uppercase" href="<?php echo e(route('module.index', ['eleve_id'=>$eleve->id])); ?>">
                Ajouter des modules
            </a>
        </div>
    </div>

    <td></td>
    <td></td>
    <td></td>

</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tpFinalLaravel\resources\views/eleve/show.blade.php ENDPATH**/ ?>